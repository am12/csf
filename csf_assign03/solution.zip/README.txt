TODO: add information about contributions of team member(s)
MS1: 
Lauren and Alan worked together on MS1 to draft and plan out the design of the cache simulator. 
Lauren worked on the Makefile while Alan worked on framework of main.cpp

MS2:
Lauren and Alan worked together on MS2 to design the LRU simulator components. Lauren worked on the main
function implementation while Alan focused on fleshing the logic of util.cpp.

MS3:
