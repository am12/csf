TODO: add information about contributions of team member(s)
MS1: 
Lauren and Alan worked together on MS1 to draft and plan out the design of the cache simulator. 
Lauren worked on the Makefile while Alan worked on framework of main.cpp

MS2:
MS3:
