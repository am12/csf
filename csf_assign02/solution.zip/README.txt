TODO: add information about contributions of team member(s)
MS1: 
For the majority of milestone 1, Alan + Lauren worked together to write and debug the functions. 
Lauren worked on the assembly code and also wrote a few of the helper function. 
Alan worked on the majority of the C code implementation.

MS2: