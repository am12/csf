TODO: add information about contributions of team member(s)
For MS1:
Alan worked on get bit, Lauren worked on uint256_create; both collaborated for uin256_createfrom32 and worked on debugging and testing together
For MS2: