TODO: add information about contributions of team member(s)
For MS1:
Alan worked on uint256_get_bits, Lauren worked on uint256_create; both collaborated for uint256_create_from_32 and worked on debugging and testing together.

For MS2:
Alan worked on uint256_format_as_hex and the rotation functions, Lauren worked on uint256_create_from_hex and the arithmetic functions; both worked on unit testing, docstrings/style editing, and debugging.